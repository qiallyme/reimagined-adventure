# Solutions from the past
- following are memories about successful solutions of related problems
- do not overly rely on them they might not be relevant

{{solutions}}