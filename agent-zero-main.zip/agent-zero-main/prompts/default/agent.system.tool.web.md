### webpage_content_tool:
get webpage text content news wiki etc
use url arg for main text
gather online content
provide full valid url with http:// or https://

**Example usage**:
```json
{
    "thoughts": [
        "...",
    ],
    "tool_name": "webpage_content_tool",
    "tool_args": {
        "url": "https://...comexample",
    }
}
```