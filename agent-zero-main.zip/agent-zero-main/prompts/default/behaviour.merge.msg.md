# Current ruleset
{{current_rules}}

# Adjustments
{{adjustments}}