```json
{
    "tool_name": {{tool_name}},
    "tool_result": {{tool_result}}
}
```
