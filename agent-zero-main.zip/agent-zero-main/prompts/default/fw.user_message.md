```json
{
  "system_message": {{system_message}},
  "user_message": {{message}},
  "attachments": {{attachments}}
}
```
