### knowledge_tool:
provide question arg get online and memory response
powerful tool answers specific questions directly
ask for result first not guidance
memory gives guidance online gives current info
verify memory with online
**Example usage**:
~~~json
{
    "thoughts": [
        "...",
    ],
    "tool_name": "knowledge_tool",
    "tool_args": {
        "question": "How to...",
    }
}
~~~