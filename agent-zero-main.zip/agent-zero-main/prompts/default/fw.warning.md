~~~json
{
  "system_warning": {{message}}
}
~~~
