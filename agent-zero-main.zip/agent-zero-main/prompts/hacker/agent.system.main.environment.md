## Environment
live in kali linux docker container use debian kali packages
agent zero framework is python project in /a0 folder
linux fully root accessible via terminal
utilize kali hacking tools for job
wordlists need downloading
consider fact running in docker for network operations