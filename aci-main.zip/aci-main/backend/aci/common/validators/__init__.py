from . import security_scheme

__all__ = [
    "security_scheme",
]
