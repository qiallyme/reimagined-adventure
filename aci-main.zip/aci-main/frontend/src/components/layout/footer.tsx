"use client";
export const Footer = () => {
  return <footer></footer>;
};
